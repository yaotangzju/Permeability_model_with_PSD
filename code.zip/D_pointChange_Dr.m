clear
load('CSD_DrCC_point.mat')
csd=real(csd)
for i=1:length(csd(:,1))%%������
    csdc(i,:)=log10(csd(i,:));
    csdpc(i,:)=log10(csdp);
   
end
figure(1)
plot(csdc,csdpc,'r*');
hold on
for i=1:length(csdc(:,1))%%%���зֶ�
    for j=1:6
csdc1(i,j)=csdc(i,j);
csdpc1(i,j)=csdpc(i,j);

csdc2(i,j)=csdc(i,j+5);
csdpc2(i,j)=csdpc(i,j+5);
    end
end
% % % ���
for i=1:length(csd(:,1))
NH1{i}=polyfit(csdc1(i,:),csdpc1(i,:),1);
NH2{i}=polyfit(csdc2(i,:),csdpc2(i,:),1);
syms x;
Df1(i)=NH1{i}(1);
Df2(i)=NH2{i}(1);
Y1(i)=NH1{i}(1)*x+NH1{i}(2);
Y2(i)=NH2{i}(1)*x+NH2{i}(2);
fplot(Y1(i),[min(csdc1(i,:)) max(csdc2(i,:))],'r-')
fplot(Y2(i),[min(csdc1(i,:)) max(csdc2(i,:))],'r-')
hold on

end
hold off
figure(2)
xlabel('Pore size(mm) log(p)')
ylabel('Cumulative percentage of pores greater(��) log(P)')
for i=1:length(csd(:,1))
x0(i)=double(solve(Y1(i)-Y2(i),x))%%��յ��Ӧ����

fplot(Y1(i),[min(csdc1(i,:)) x0(i)],'r-')
hold on

fplot(Y2(i),[x0(i) max(csdc2(i,:))],'r-')
hold on

% save('Df_Dr.mat','Df1','Df2','x0')
end
save('Df_CCpoint.mat','Df1','Df2','x0')
plot(csdc,csdpc,'r*');
hold off