clear
load('SYP4.mat','Hmin','H4','M4');

% % �������׵��ۼ�Ƶ��
for i=1:length(M4)
    PP(i)=0;
    b=H4(i);
    for j=1:length(M4)
       a =H4(j);
        
        if a>=b
            PP(i)=M4(j)+PP(i);
        
        end
    
    end
    
end
PP;
% % ������С�׵��ۼ�Ƶ��
for i=1:length(M4)
    pp(i)=0;
    b=Hmin(i);
    for j=1:length(M4)
       a =Hmin(j);
        
        if a>=b
            pp(i)=M4(j)+pp(i);
        
        end
    
    end
    
end
pp;

save('SY.mat','PP','pp')
