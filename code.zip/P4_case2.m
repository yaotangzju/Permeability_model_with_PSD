function [Pmax,pav,Aer]=KD(d1,d2,d3,d4)
syms x t t1 t6;
assume(0<t<pi);

r1=d1/2;
r2=d2/2;
r3=d3/2;
r4=d4/2;
r13=r1+r3  ;
r34=r4+r3;
r24=r2+r4;
r12=r1+r2;
% % ���4/1��С
r23=r2+r3;
eq1=(r12^2+r13^2-2*r12*r13*cos(t))^(0.5)-r23;
tt1=eval((solve(eq1,t)));
tt2=tt1(tt1<pi);
xmin11=tt2(0<tt2);

% % ���4/1���
syms t3 t4 ;
r14=r1+r4;
assume(0<t3<pi);
assume(0<t4<pi);
eq4=(r13^2+r14^2-r34^2)/(2*r13*r14)-cos(t3);
eq5=(r12^2+r14^2-r24^2)/(2*r12*r14)-cos(t4);
tt1=eval((solve(eq4,t3)));
tt2=tt1(tt1<pi);
J1=tt2(0<tt2);
tt1=eval((solve(eq5,t4)));
tt2=tt1(tt1<pi);
J2=tt2(0<tt2);
SS=J1+J2;

if SS>=2*pi-xmin11
    xmax11=2*pi-xmin11;
end
if SS<2*pi-xmin11
    xmax11=SS;
end
xmax11;


% % �ý�1��ʾ�����
if xmax11>=pi 
    xmin11<=x<=pi;
y23=(r12^2+r13^2-2*r12*r13*cos(x))^(0.5);

x4=acos((r34^2+r24^2-y23^2)/(2*r34*r24));

x21=acos((y23^2+r12^2-r13^2)/(2*y23*r12))+acos((y23^2+r24^2-r34^2)/(2*y23*r24));
x31=2*pi-x-x21-x4;

assume(pi<=x<=xmax11);

x22=-acos((y23^2+r12^2-r13^2)/(2*y23*r12))+acos((y23^2+r24^2-r34^2)/(2*y23*r24));
x32=2*pi-x-x22-x4;
end
if xmax11<pi
  xmin11<=x<=xmax11;
y23=(r12^2+r13^2-2*r12*r13*cos(x))^(0.5);

x4=acos((r34^2+r24^2-y23^2)/(2*r34*r24));

x21=acos((y23^2+r12^2-r13^2)/(2*y23*r12))+acos((y23^2+r24^2-r34^2)/(2*y23*r24));
x22=x21;
x31=2*pi-x-x21-x4;
x32=x31;
end
    
% % ���ý�14�����ı������
 S1=r13*r12*sin(x)/2;
 S2=r34*r24*sin(x4)/2;
 S=S1+S2;

% % �����϶���
A4=x4/(2*pi)*pi*r4^2;
A1=x/(2*pi)*pi*r1^2;
A31=x31/(2*pi)*pi*r3^2;
A32=x32/(2*pi)*pi*r3^2;
A21=x21/(2*pi)*pi*r2^2;
A22=x22/(2*pi)*pi*r2^2;

if xmax11>=pi
  
  AA2=((S-A1-A4-A32-A22)*4/pi)^0.5;%��Ч���Բ���Ƕȴ��ڦ�
  AA1=((S-A1-A4-A31-A21)*4/pi)^0.5;%��Ч���Բ���Ƕ�С�ڦ�

 t11=xmin11:0.00001:pi;
    f1=inline(AA1);
    [P(1),s1]=max(f1(t11));
    p(1)=min(f1(t11));
 t22=pi:0.00001:xmax11;
    f2=inline(AA2);
     [P(2),s2]=max(f2(t22));
    p(2)=min(f2(t22));
    [Pmax,MM]=max(P);%����϶
if MM<2
   Aer=s1*0.00001+xmin11;%���׾���Ӧ�Ƕ�
else MM>1
   Aer=s2*0.00001+pi;   
end

pav=(p(1)+p(2))/(2*2^0.5);%��С��϶�ߴ磬ƽ����϶������Ч���Բ
end

if xmax11<=pi
    
AA1=((S-A1-A4-A31-A21)*4/pi)^0.5;

f1=inline(AA1);
t33=xmin11:0.00001:xmax11;

 [Pmax,SS]=max(f1(t33));
 Aer=SS*0.00001+xmin11;
 p(1)=f1(xmin11);
 p(2)=f1(xmax11);
 pav=(p(1)+p(2))/(2*2^0.5);
end

pav;
Aer;
Pmax;
end